package com.example.atelier2;


import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class Database extends SQLiteOpenHelper{
    public static final String DB_NAME = "atelier4";
    public static final int DB_VERSION = 1;

    public static final String TB_NAME = "users";
    public static final String CL_ID = "id";
    public static final String CL_FIRSTNAME = "first_name";
    public static final String CL_LASTNAME = "last_name";

    public Database(Context c) {
        super(c, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE " + TB_NAME + " (" + CL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + CL_FIRSTNAME + " TEXT, " + CL_LASTNAME + " TEXT);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
    public Boolean addUser(User user) {

        SQLiteDatabase db = getWritableDatabase();
        ContentValues v = new ContentValues();

        v.put(CL_FIRSTNAME, user.getFirstName());
        v.put(CL_LASTNAME, user.getLastName());

        return db.insert(TB_NAME, null, v) != -1;
    }
    public ArrayList<User>getUserData(){

        ArrayList<User> lise = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();

        @SuppressLint("Recycle") Cursor cursor = db.rawQuery("Select * FROM " + TB_NAME, null);

        if (cursor != null) {
            while (cursor.moveToNext()) {

                int id = cursor.getInt(0);
                String firstName = cursor.getString(1);
                String lastName = cursor.getString(2);

                User user= new User(firstName,lastName);
                lise.add(user);
            }
        }
        return lise;
    }
}