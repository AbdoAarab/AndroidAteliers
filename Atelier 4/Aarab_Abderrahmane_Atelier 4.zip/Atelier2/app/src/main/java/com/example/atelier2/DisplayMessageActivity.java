package com.example.atelier2;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import java.util.List;

public class DisplayMessageActivity extends AppCompatActivity {

    TextView tv_firstName,tv_lastName;
    String firstName,lastName;


    @SuppressLint("MissingInflatedId")

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_message);

        tv_firstName=findViewById(R.id.tv_firstName);
        tv_lastName=findViewById(R.id.tv_lastName);

        Database database=new Database(DisplayMessageActivity.this);

        database.getReadableDatabase();
        List<User> users=database.getUserData();

        for (User user:users){
            firstName=user.getFirstName();
            lastName=user.getLastName();
        }
        tv_firstName.setText(firstName);
        tv_lastName.setText(lastName);
    }
}