package com.example.atelier2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Database db;

    EditText tv_firstName,tv_lastName;
    Button submit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tv_firstName = findViewById(R.id.firstName);
        tv_lastName = findViewById(R.id.lastName);
        submit = findViewById(R.id.submit);

        db = new Database(this);
    }

    public void submitData(View view) {

        // get inputted strings
        String firstName = tv_firstName.getText().toString();
        String lastName = tv_lastName.getText().toString();

        // create user object from inputs
        User user = new User(firstName, lastName);

        // add user to database
        if (db.addUser(user)) {
            Toast.makeText(MainActivity.this, "Success!", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(MainActivity.this, DisplayMessageActivity.class);
            startActivity(intent);
        } else Toast.makeText(MainActivity.this, "Error!", Toast.LENGTH_SHORT).show();
    }
}