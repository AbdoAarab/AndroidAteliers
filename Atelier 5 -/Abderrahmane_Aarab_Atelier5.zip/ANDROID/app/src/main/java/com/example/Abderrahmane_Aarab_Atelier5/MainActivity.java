package com.example.Abderrahmane_Aarab_Atelier5;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class MainActivity extends AppCompatActivity implements LocationListener {
    private LocationManager locationManager;
    private TextView textViewLocation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnGetLocation = findViewById(R.id.btnGetLocation);
        textViewLocation = findViewById(R.id.textViewLocation);

        // Request location permission
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
        // Get location button click listener
        btnGetLocation.setOnClickListener(view -> {
            // Check if location permission is granted
            if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED) {
                // Get location using LocationManager
                locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 5000, 5, this);
            } else {
                textViewLocation.setText("Location permission denied.");
            }
        });
    }
    @Override
    public void onLocationChanged(Location location) {
        // Display location in the TextView
        String latitude = String.valueOf(location.getLatitude());
        String longitude = String.valueOf(location.getLongitude());
        String Altitude = String.valueOf(location.getAltitude());
        textViewLocation.setText("Latitude: " + latitude + "\nLongitude: " + longitude + "\nAltitude: " + Altitude);
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
    }

    @Override
    public void onProviderEnabled(String provider) {
    }

    @Override
    public void onProviderDisabled(String provider) {
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Remove location updates when the app is destroyed
        if (locationManager != null) {
            locationManager.removeUpdates(this);
    }
}}