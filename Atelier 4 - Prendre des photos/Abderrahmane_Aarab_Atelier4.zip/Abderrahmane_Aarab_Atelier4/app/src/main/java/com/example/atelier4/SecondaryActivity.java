package com.example.atelier4;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.io.File;
import java.util.ArrayList;

public class SecondaryActivity extends AppCompatActivity {
    private ListView imageList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_secondary);

        // Get an array of all image file paths
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File[] imageFiles = storageDir.listFiles();
        ArrayList<String> imagePathList = new ArrayList<String>();
        for (File file : imageFiles) {
            imagePathList.add(file.getAbsolutePath());
        }

        // Set the adapter for the ListView
        imageList = findViewById(R.id.image_list);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, imagePathList);
        imageList.setAdapter(adapter);

        // Set an OnItemClickListener to send the selected image path back to MainActivity
        imageList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String imagePath = (String) parent.getItemAtPosition(position);
                Intent intent = new Intent();
                intent.putExtra("imagePath", imagePath);
                setResult(Activity.RESULT_OK, intent);
                finish();
            }
        });
    }

}